module appstart {
 // Requires the module appfuncs.
 requires appfuncs;
}
module appfuncs {
    exports com.simplefuncs;
    // can also export to specific module - or modules in comma separated list
    // exports com.simplefuncs to appstart; 
}
